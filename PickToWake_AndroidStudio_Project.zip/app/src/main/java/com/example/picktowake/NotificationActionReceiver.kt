package com.example.picktowake

import android.content.*

class NotificationActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "com.example.picktowake.ACTION_STOP"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_STOP) {
            SettingsStore.setEnabled(context, false)
            WakeService.stop(context)
        }
    }
}
