package com.example.picktowake

import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            if (SettingsStore.isEnabled(context)) {
                WakeService.start(context)
            }
        }
    }
}
